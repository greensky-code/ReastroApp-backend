import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-approved-kyc',
  templateUrl: './driver-approved-kyc.component.html',
  styleUrls: ['./driver-approved-kyc.component.css']
})
export class DriverApprovedKycComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
