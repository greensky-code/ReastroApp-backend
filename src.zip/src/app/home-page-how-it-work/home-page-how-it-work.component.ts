import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-how-it-work',
  templateUrl: './home-page-how-it-work.component.html',
  styleUrls: ['./home-page-how-it-work.component.css']
})
export class HomePageHowItWorkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
