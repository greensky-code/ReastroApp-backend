import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-without-login-header',
  templateUrl: './without-login-header.component.html',
  styleUrls: ['./without-login-header.component.css']
})
export class WithoutLoginHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
