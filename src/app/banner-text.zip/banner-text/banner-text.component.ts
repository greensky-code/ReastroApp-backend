import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { ApiServiceService } from '../api-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { isBuffer } from 'util';
declare var $: any;
@Component({
  selector: 'app-banner-text',
  templateUrl: './banner-text.component.html',
  styleUrls: ['./banner-text.component.css']
})
export class BannerTextComponent implements OnInit {


  howForm:FormGroup;

  valueTo: any;

  language: any;

  value: string;

  values: any;

  bannerText: any;

  types: any;

  errorMessage: any;

  showOtpComponent = true;

  varificationCode: any;

  bannerValue: string;

  howWork: any;

  arr:any=[];
  createBin: any;

  bannerList:any=[];
  howWorkdata: any;
  bannerTYranslateList: any=[];

  constructor(private service: ApiServiceService, private router: Router, private fb: FormBuilder, private activateRouter: ActivatedRoute, private spinner: NgxSpinnerService) { }

  ngOnInit() {

    this.activateRouter.params.subscribe(res => {

      console.log('res', res)

      this.values = res.valueTo

      this.language = res.language

      this.types = res.type

      console.log('types', this.language)


    })
    if(this.values == 'banner-text'){

      this.howForm = this.fb.group({

        bannertitle: [''],

        bannerDescription: [''],

      })

    }
    else  if(this.values == 'how-it-work'){

    this.howForm = this.fb.group({

      todos: [''],

      description: [''],

    })

  }

  if(this.values == 'how-it-work'){

      if(this.language == 'th' ){

        this.getHowitWorkTranslate()

      }else {

        this.getData()

      }


  }

  // **************************************************** How it Work Section ****************************************//


  }



getData(){

  this.spinner.show()

  this.service.getApi(`master/how-it-works`,1).subscribe((data)=>{
 
    if(data.status == 200 ){

      this.spinner.hide()
    // this.howWorkdata=data.body

    this.bannerList=data.body;

    this.howForm = this.fb.group({
      
    todos: this.fb.array( this.bannerList .map(t => t.title)),

    description : this.fb.array( this.bannerList .map(b => b.description)),
    });
  }

 
  }, err => {

      if (err.status == 403 || err.status == 401) {

        this.spinner.hide()

        this.service.logout();

      }

      else if (err.status == 400) {

        this.spinner.hide()

        this.service.toastErr(err.error.message)

      }
      else if (err.status == 500) {

        this.spinner.hide()

        this.service.toastErr(err.statusText)

      }

      this.spinner.hide()
    });
}




handleTitleInput(e, i, key){

  if(this.language == 'th'){

    console.log("title=1 ", e, i);

    if(key=="title"){

      this.bannerTYranslateList[i][key]=e.target.value;

    }
    else {

      this.bannerTYranslateList[i][key]=e;

    }
}else{

  console.log("title=1 ", e, i);

  if(key=="title"){

    this.bannerList[i][key]=e.target.value;

  }

  else {

    this.bannerList[i][key]=e;

  }

}

  console.log("title= ", this.bannerList, i);
}


submitHowIt(){

  this.spinner.show()

  let object={
    "how_it_works"    :  this.bannerList
  }

  this.service.postApi(`master/how-it-works`,object,1).subscribe(res=>{

    if(res.status == 200 ){

      this.service.showSuccess(res.body.message)

      this.spinner.hide()

      this.router.navigate(['website-home-page'])
    }
  }, err => {

    if (err.status == 403 || err.status == 401) {

      this.spinner.hide()

      this.service.logout();

    }

    else if (err.status == 400) {

      this.spinner.hide()

      this.service.toastErr(err.error.message)

    }
    else if (err.status == 500) {

      this.spinner.hide()

      this.service.toastErr(err.statusText)

    }

    this.spinner.hide()
  })

}


getHowitWorkTranslate(){

  this.service.getApi(`master/how-it-works?lang=${this.language}`,1).subscribe(res=>{

    if(res.status == 200 ){

      this.bannerTYranslateList=res.body;

      this.howForm = this.fb.group({
      
        todos: this.fb.array( this.bannerTYranslateList .map(t => t.title)),
    
        description : this.fb.array( this.bannerTYranslateList .map(b => b.description)),
        });
      

      console.log('bannerTYranslateList',this.bannerTYranslateList[0].how_it_work)
    }


  }, err => {

    if (err.status == 403 || err.status == 401) {

      this.spinner.hide()

      this.service.logout();

    }

    else if (err.status == 400) {

      this.spinner.hide()

      this.service.toastErr(err.error.message)

    }
    else if (err.status == 500) {

      this.spinner.hide()

      this.service.toastErr(err.statusText)

    }

    this.spinner.hide()
  })
}
// -----------------------------------How it work Translate ---------------------------//


updateHowWorkTranslate(){

  this.spinner.show()

  let object={

    "how_it_works_thai"     : this.bannerTYranslateList.language,

    "title"                 : this.bannerTYranslateList.title,

    "how_it_works"          :  this.bannerTYranslateList.how_it_work,

    "description"           : this.bannerTYranslateList.description

  }

  console.log('object',object)

  this.service.postApi('master/how-it-works-translate',object,1).subscribe(res=>{

    if(res.status == 200 ){

      this.spinner.hide()


      this.service.showSuccess(res.body.message)

    }
  })

}

// ------------------------------Update methos and Translate Api--------------------------------//

updateWork(){

  if(this.language == 'th' ){

    this.updateHowWorkTranslate()

  }else {

    this.submitHowIt()

  }

}

}


